window.addEventListener('offline', function() {
  var offlineNotification = document.getElementById('offline-notification');
  offlineNotification.classList.add('show');
});
window.addEventListener('online', function() {
  var offlineNotification = document.getElementById('offline-notification');
  offlineNotification.classList.remove('show');
});